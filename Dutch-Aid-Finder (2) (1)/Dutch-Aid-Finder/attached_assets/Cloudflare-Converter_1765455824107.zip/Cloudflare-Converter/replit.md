# Searchforhelp - Crisis Navigator

## Overview
A static website that provides crisis helpline resources for people in the Netherlands. The site helps users find emergency contacts and support services for various situations including mental health, abuse, addiction, and more.

**Purpose**: Help people in distress quickly find the right helpline in the Netherlands.

**Current State**: Complete static website ready for deployment to Cloudflare Pages.

## Project Structure
```
/
├── index.html          # Home page with hero, categories, featured helplines
├── categories.html     # All categories page
├── category.html       # Category detail page (uses ?slug= parameter)
├── about.html          # About page with mission, features, emergency contacts
├── styles.css          # All CSS styles
├── data.js             # Categories and helplines data
├── app.js              # JavaScript functionality (search, navigation, rendering)
├── server.py           # Local development server (not needed for Cloudflare)
└── .gitignore          # Git ignore file
```

## Deployment to Cloudflare Pages

### Option 1: Direct Upload
1. Go to Cloudflare Dashboard → Pages
2. Create a new project
3. Upload the following files:
   - index.html
   - categories.html
   - category.html
   - about.html
   - styles.css
   - data.js
   - app.js

### Option 2: Git Integration
1. Push this code to a GitHub repository
2. Connect Cloudflare Pages to the repository
3. Build settings:
   - Build command: (leave empty)
   - Build output directory: `/` or `.`

## Features
- Emergency helpline numbers for Netherlands
- 8 categories of support (Mental Health, Abuse, Addiction, Youth, LGBTQ+, Domestic, Financial, Legal)
- 27+ helplines with phone numbers, websites, hours, languages
- Search functionality
- Mobile-responsive design
- No build process required
- Pure HTML/CSS/JavaScript

## Data
All helpline data is stored in `data.js` as JavaScript arrays. To add or modify helplines:
1. Edit the `categories` array for new categories
2. Edit the `helplines` array for new helplines

## Recent Changes
- December 2024: Initial conversion from React/TypeScript to static HTML/CSS/JS

## User Preferences
- Dutch language (primary)
- Calming, professional design
- Easy access to emergency numbers
